<?php
namespace MyTigreTrip;

class Note
{
    protected $domain;
    protected $json;

    

}
