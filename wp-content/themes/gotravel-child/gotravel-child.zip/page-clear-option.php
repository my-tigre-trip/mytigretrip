<p></p>
<?php
require 'wp-load.php';
session_start();
if( session_id() !== null ){
	session_regenerate_id(); 
	session_destroy();
}

wp_redirect( home_url().'/#boat-selection' );
