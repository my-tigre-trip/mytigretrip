<?php

session_start();

use MyTigreTrip\Translation;
use App\Models\Calculator;
use App\Models\MyTrip;
use App\Models\Tour;

/**
*
*
*/
function calculatePriceMtt()
{
    session_start();
    $response = [  ];
    if ($_POST['_token'] === session_id()) {
        $tour = new Tour($_POST['tourSlug']);

        $myTrip = unserialize($_SESSION['myTrip']);

        #si no existe myTrip lo creamos
        if ($myTrip === false) {
            $myTrip = new MyTrip(session_id());
        }
        #verificamos si ya esta bloqueado
        if ($myTrip->lock !== null) {
            echo jsonResponse([
              'valid' => false,
              'messages' => renderMessage('summary-stage')
            ]);
            die();
        }
       #transferimos todos los campos
        $myTripBoat = $myTrip->getBoat($tour->boat);
        //var_dump($myTripBoat);
        if ( isset($_POST['adults'])) {
            $myTripBoat->adults = $_POST['adults'];
            $tour->adults = $_POST['adults'];

        }
        //echo "tour adults $tour->adults";
        if ( isset($_POST['children'])) {
            $myTripBoat->children = $_POST['children'];
            $tour->children = $_POST['children'];
        }

        if (isset($_POST['specialActivityPeople']) && $_POST['specialActivityPeople'] > 0) {
            $myTripBoat->specialActivityPeople = $_POST['specialActivityPeople'];
            $tour->specialActivityPeople = $_POST['specialActivityPeople'];
        }

        if (isset($_POST['optional']) && $_POST['optional'] === 'yes') {
            $tour->optionalSelected = true;
        } else {
            $tour->optionalSelected = false;
        }
        #evaluamos el tipo de bote correspondiente al tour y lo asignamos
        $myTrip->addTour($tour);
        //determinamos si hay que elegir un trip mas (build your own) y
        $myTripBoat->setNextStep();
        $nextStep = $myTripBoat->nextStep;
        $myTrip->setBoat($myTripBoat);
        //$MyTripBoat->adults = $_POST['adults'];
        #check de mood2
        if ($myTripBoat->boat === 'full-day' && $tour->mood === 2 && $myTripBoat->mood1 === null) {
          $myTripBoat->mood2 = null;
          $myTrip->setBoat($myTripBoat);
          $_SESSION['myTrip'] =  serialize($myTrip);
          echo jsonResponse([
            'valid' => false,
            'messages' => renderMessage('full-day')
          ]);
          die();
        }
        #evaluamos el goto
        $lockCollision = false;
    //    $response['redirect'] = true;

        if (isset($_POST['nextStep']) && $_POST['nextStep'] === 'true') {
            $response['redirect'] = true;
            if ($nextStep === 'my-trip') {
                $myTrip->lock = $myTripBoat;
            }
        }

        //nextStepText
        if ($nextStep === 'my-trip') {
            $response['nextStepText'] = 'This is my Trip';
        } else {
            $response['nextStepText'] = 'Select & Continue';
        }

        /*if (isset($_POST['lock']) && $_POST['lock'] === 'yes') {
            #si el slot esta disponible lo escribimos
            $response['redirect'] = true;
            if ($myTrip->lock === null) {
                $myTrip->lock = $myTripBoat;

            } else {
                $lockCollision = true;
                $response['lockCollision'] = true;
            }
        } else {
              $myTrip->lock = null;
        }*/
        $_SESSION['myTrip'] =  serialize($myTrip);
        # enviamos response
    //$myTrip->priceDetailHtml();
        //print_r($myTripBoat);
        //$response['debug'] = $myTripBoat;
        //$response['valid'] = $myTrip->validateCalculator() ;
        $response['valid'] = true;
        $response['nextStep'] = home_url().'/'.$nextStep;
        $response['view'] = renderPriceResult($tour->boat);
        //echo "tour category ".$myTripBoat->mood2->category->slug.'<br>';
        echo jsonResponse($response);
    } else {
    //
        http_response_code(500);
    }
}

/**
*
*
*/
function summaryMtt(){
    session_start();
    $myTrip = unserialize($_SESSION['myTrip']);
    $myBoat = $myTrip->lock;
    $response = [  ];
    if($_POST['_token'] === session_id() ){
            $myTrip->stage = 'summary';
            if( isset( $_POST['pay-on-island'] ) ){
                $myTrip->payOnIsland = true;
                $response['payOnIsland'] = $myTrip->payOnIsland ;
            }else{
                $myTrip->payOnIsland = false;
            }

            if( isset( $_POST['car'] ) ){
                $myTrip->car = true;
                $response['car'] = $myTrip->car ;
            }else{
                $myTrip->car = false;
            }

            //guardamos el objeto nuevamente
            $_SESSION['myTrip'] =  serialize($myTrip);
          //  $response['view'] = $myTrip->priceDetail();
            //$response['post'] = json_encode($_POST);
            $response['view'] = renderSummary();
            echo jsonResponse($response);
    } else {
        echo jsonResponse(['valid' => 'no-boat']);
    }
}

/**
*
*/
function getTheTrip()
{
    session_start();
    $myTrip = unserialize($_SESSION['myTrip']);
    $response = [  ];

    if ($_POST['_token'] === session_id()) {
        //  $valid = $myTrip->validateFields();
        //zoho hace una validacion
        $valid = true;
        if ($valid === true) {
              $myTrip->save();
              $_SESSION['myTrip'] =  serialize($myTrip);
              //completada la primera parte pasamos al formulario de contacto
              $response = ['errors' => false,
                          // 'redirect' => home_url().'/my-trip-checkout'
                           'redirect' => home_url().'/my-trip-contact-information'
              ];
        } else {
              $response = ['errors' => $valid ];
        }
    }


    $json = json_encode($response);
    if ($json === false) {
        // Avoid echo of empty string (which is invalid JSON), and
        // JSONify the error message instead:
        $json = json_encode(array("jsonError", json_last_error_msg()));
        if ($json === false) {
            // This should not happen, but we go all the way now:
            $json = '{"jsonError": "unknown"}';
        }
        // Set HTTP response status code to: 500 - Internal Server Error
        http_response_code(500);
    }
    header("Content-Type: application/json;charset=utf-8");
    echo trim($json);
}

function tourType($tourId){

    $categories = wp_get_post_terms($tourId, 'tour-category');

    foreach($categories as $c){
        echo "<br> $c->slug";
    }
}

/**
*
*
*/
function jsonResponse($message = null, $code = 200)
{
    // clear the old headers
    header_remove();
    // set the actual code
    http_response_code($code);
    // set the header to make sure cache is forced
    header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
    // treat this as json
    header('Content-Type: application/json');
    $status = array(
        200 => '200 OK',
        400 => '400 Bad Request',
        422 => 'Unprocessable Entity',
        500 => '500 Internal Server Error'
        );
    // ok, validation error, or failure
    header('Status: '.$status[$code]);
    // return the encoded json
    return json_encode(array(
        'status' => $code < 300, // success or not?
        'message' => $message
        ));
}
