<?php
use Jenssegers\Blade\Blade;
use App\Models\Calculator;
use Symfony\Component\Translation\Translator;
use Symfony\Component\Translation\Loader\ArrayLoader;

/**
*
*/
function options_form_zoho_shortcode($atts){
$blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');

echo $blade->make('zoho-options-form', ['name' => 'Jose']);
}#fin shortcode

add_shortcode( 'formulario_opciones_zoho', 'options_form_zoho_shortcode' );

/**
*
*/
function contact_form_zoho_shortcode($atts){
$blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');

echo $blade->make('zoho-form', ['name' => 'Jose']);
}#fin shortcode

add_shortcode( 'formulario_contacto_zoho', 'contact_form_zoho_shortcode' );

/**
*
*
*/
//check list include - not includes
function include_not_include_shortcode($atts){
$blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');

echo $blade->make('checklist', ['name' => 'Jose']);
}#fin shortcode

add_shortcode( 'include_not_include', 'include_not_include_shortcode' );

/**
* formulario de opciones (auto , pagar en la isla) previa a entrada de data
*
*/
function renderZohoOptionsForm()
{
    $blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');
    $myTrip = unserialize($_SESSION['myTrip']);

    if ($myTrip === false) {
        wp_redirect(home_url());
        die();
    }

    $myBoat = $myTrip->lock;
    $price = Calculator::calculatePrice($myBoat);

    echo $blade->make('zoho-options-form', ['myTrip' => $myTrip, 'myBoat' => $myBoat]);
}

/**
*
*
*/
function renderZohoForm()
{
  $blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');
  $myTrip = unserialize($_SESSION['myTrip']);
  if ($myTrip === false) {
     wp_redirect(home_url());
     die();
  } else {
    $myBoat = $myTrip->lock;
    $price = Calculator::calculatePrice($myBoat);
    $notes = $myTrip->getNotes($myBoat, $price['tourDetail']['price']);
    echo $blade->make('zoho-form', ['myTrip' => $myTrip,
       'myBoat' => $myBoat,
       'boatDetail' => $price['boatDetail'],
       'tourDetail' => $price['tourDetail'],
       'finalPrice' => $price['finalPrice'],
       'price' => $price,
       'notes' => $notes
     ]);
  }

}
/**
*
*
*/
function renderSummary()
{
    $blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');
    $myTrip = unserialize($_SESSION['myTrip']);

    $myBoat = $myTrip->lock;
    $price = Calculator::calculatePrice($myBoat, $myTrip);
    $notes = $myTrip->getNotes($myBoat, $price['tourDetail']['price']);
    return $blade->make('calculator.summary', ['myTrip' => $myTrip,
       'myBoat' => $myBoat,
       'boatDetail' => $price['boatDetail'],
       'tourDetail' => $price['tourDetail'],
       'finalPrice' => $price['finalPrice'],
       'price' => $price,
       'notes' => $notes
       ]).'';
}

/**
*
*
*
*/
function renderPriceResult($boat)
{
  /*$translator = new Translator('fr_FR');
$translator->addLoader('array', new ArrayLoader());
$translator->addResource('array', array(
  'Symfony is great!' => 'Symfony est super !',
), 'fr_FR');*/

    //var_dump($translator->trans('Symfony is great!'));
    $blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');
    $myTrip = unserialize($_SESSION['myTrip']);
    //$myTrip->calculatePrice();
    //$mtt = new App\Models\MyTrip(1);
    $currentBoat = $myTrip->getBoat($boat);
  //  print_r($currentBoat);
    $price = Calculator::calculatePrice($currentBoat);
    $notes = $myTrip->getNotes($currentBoat, $price['tourDetail']['price']);
      //print_r($price);
    return $blade->make('calculator.price-result', ['currentBoat' => $currentBoat,
        'boatDetail' => $price['boatDetail'],
        'tourDetail' => $price['tourDetail'],
        'finalPrice' => $price['finalPrice'],
        'price' => $price,
        'notes' => $notes
         ]).'';
}

/**
* mensages de error: summary-stage
*
*/
function renderMessage($message)
{
  $blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');

  return $blade->make('calculator.messages.'.$message).'';
}

//validacion
function validateRequiredFields()
{

    $myTrip = unserialize($_SESSION['myTrip']);
    $myBoat = $myTrip->lock;
//  $response['status'] = 'error';
    $response['status'] = 'valid';
    $break = false;
    if (empty($_POST['firstName']) || empty($_POST['lastName'])) {
        $break = true;
        $response['status'] = 'error';
        $response['message'] = 'First name and last name are required';
    } elseif (!$break && (empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))) {
        $break = true;
        $response['status'] = 'error';
        $response['message'] = 'email is empty or no valid';
    } elseif (!$break && empty($_POST['day'])) { // revisar
        $break = true;
        $response['status'] = 'error';
        $response['message'] = 'date is no valid';
    } elseif (!$break && empty($_POST['month'])) { // revisar
        $break = true;
        $response['status'] = 'error';
        $response['message'] = 'date is no valid';
    } elseif (!$break && empty($_POST['year'])) { // revisar
        $break = true;
        $response['status'] = 'error';
        $response['message'] = 'date is no valid';
    } elseif (!$break && ( ($myTrip->car || $myBoat->boat === 'full-day') && empty($_POST['pickupAddress']))) {
        $break = true;
        $response['status'] = 'error';
        $response['message'] = 'pick up address is required';
    }

    if ($break) {
        echo jsonResponse($response);
        die();
    }
}

/**/
function renderCalculator()
{
    $blade = new Blade(__DIR__.'/App/Views', __DIR__.'/App/Cache');
  //  $myTrip = unserialize($_SESSION['myTrip']);

    echo $blade->make('calculator.calculator', ['myTrip' => null ]);
}

add_shortcode( 'calculadora', 'renderCalculator' );
