
    <div class="wpb_wrapper">

      <h2>Good to know</h2>
      <div class="vc_col-md-3 vc_col-sm-12">
        This mood includes
      </div>
      <div class="vc_col-md-3 vc_col-sm-12">
        <ul>
          <li>Private speed-boat trip through Tigre´s highlights: historical sites, belle époque architecture & modern way of life + detour into beautiful shallow rivers and natural channels, away from touristic routes</li>
          <li>Boat driver & private guide on board</li>
          <li>Boat driver & private guide on board</li>
        </ul>
      </div>
    </div>
