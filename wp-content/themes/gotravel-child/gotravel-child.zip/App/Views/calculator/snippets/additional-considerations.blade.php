@if ($tour->isLuxury())
<div class="mtt-optional">
  <input class="update-calculator" id="luxury" name="optional" value="yes" type="checkbox" <?php if( false ){  ?> checked <?php } ?> >
  <input name="isLuxury" value="yes" type="hidden"  />
  <label for="luxury" >I´d like to make use of Lodge´s facilities (swimming pool, pedal boats)</label>
</div>
@endif
@if ($tour->isRanch())
<div class="mtt-optional">
  <input class="update-calculator" id="ranch" name="optional" value="yes" type="checkbox" <?php if( false ){  ?> checked <?php } ?> >
  <input  name="isRanch" value="yes" type="hidden" />
  <label for="ranch" >I´d rather have lunch, participate on one activity and skip tea.</label>
</div>
@endif
