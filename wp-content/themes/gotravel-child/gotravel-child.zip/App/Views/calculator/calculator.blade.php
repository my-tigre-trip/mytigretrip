<?php
use MyTigreTrip\Translation;
use App\Models\Tour;

session_start();
/*
$tour = new Tour(basename(get_permalink()));
echo $tour->getTourBoat()->slug;
echo ' <br>';
echo $tour->boat;
echo ' <br>';
echo $tour->mood;
*/
    $tour = new Tour(basename(get_permalink()));
  //  print_r($tour->product);
  //  $s = \App\Models\Woo::findProduct(basename(get_permalink())) ;
  //  if ($tour->isRanch() || $tour->isLuxury()){
      //echo 'HHHH';
  //  }
    // print_r($_SESSION['myTrip']);
  ;
    $t = new Translation('calculator-en');
    global $wp;
    $adults = 0;
    $children = 0;
    $currentTour = $tour;

    $myTrip = unserialize($_SESSION['myTrip']);
    if ($myTrip !== false) {
       $tourBoat = $myTrip->getBoat($tour->boat);
       $adults = $tourBoat->adults;
       $children = $tourBoat->children;
       $specialActivityPeople = $tourBoat->specialActivityPeople;
      // echo $tourBoat->mood1->category->slug;

    }
  // echo 'ad '. $adults ;

  //  $myTrip = unserialize($_SESSION['myTrip']);
    $current_url = home_url(add_query_arg(array(), $wp->request));
    $action = '';
    $valid = true;
    //var_dump($tour->category);
    $goBack = getGoBackUrl($tour->category->slug);

	?>
	<div class="mkdf-tour-booking-form-holder mkdf-boxed-widget">

	<h5 class="mkdf-tour-booking-title">Plan your Tigre Trip with us today!</h5>
  <div id="mtt-validator-messages">
  @if($valid !== true)
      {{--
     @include('calculator.messages.'.$valid)
       --}}
  @elseif($valid === true)
  </div>

	<form id="mkdf-tour-booking-form" method="post" action="" class="mtt-form">
  
    @if(basename(get_permalink()) !== 'yacht-a-dramatic-entrance')    
      @include('calculator.snippets.form')
      @include('calculator.snippets.prices')
      @include('calculator.snippets.buttons')
    @else
      <p>Are you part of a group of 6 to 28 people?</p>
      <p>Then find out more about our Private Yacht Experiences!</p>
      @include('calculator.snippets.contact-us')
    @endif
  </form>
   @endif
	
</div>
