<p>You have already selected a trip</p>
<a class="back-to-checkout" href="<?php echo home_url().'/my-trip' ?>">Go to checkout!!</a>
<hr>
<a class="clear-option" href="<?php echo home_url().'/clear-option'?>"> Clear My Tigre Trip and start again</a> 
