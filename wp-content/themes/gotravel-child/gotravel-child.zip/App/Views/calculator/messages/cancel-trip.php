
    <div class="row">
        <div id="mtt-cancel-trip" class="text-danger" >
          <button><i class="fa fa-window-close text-danger" aria-hidden="true"></i></button>
          <a class="clear-option text-danger" href="<?php echo home_url().'/clear-option'?>"> Clear My Tigre Trip and start again</a>
        </div>
    </div>
