<!-- Horarios de lancha o pick up -->
<div class="col-md-6 form-group pb-3">
  <?php if($myBoat->boat === 'full-day'): ?>
    <?php echo $__env->make('zoho-form.car-included', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php elseif($myBoat->boat !== 'full-day' && $myTrip->car): ?>
    <?php echo $__env->make('zoho-form.car-included', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php elseif($myBoat->boat !== 'full-day' && !$myTrip->car): ?>
    <?php echo $__env->make('zoho-form.no-car', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>
</div>
