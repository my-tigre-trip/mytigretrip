<?php wp_nonce_field('mkdf_tours_booking_form', 'mkdf_tours_booking_form'); ?>
<input type="hidden" name="back" value="<?php echo $current_url;?>"/>
<input type="hidden" name="tour-price" value="<?php echo mkdf_tours_get_tour_price(get_the_ID());?>"/>
<input type="hidden" name="tour-title" value="<?php echo get_the_title();?>"/>
<input type="hidden" name="tour-id" value="<?php echo esc_attr(get_the_ID()); ?>"/>
<input type="hidden" name="tour-slug" value="<?php echo basename(get_permalink()); ?>"/>
<input type="hidden" name="_token" value="<?php session_start(); echo session_id(); ?>" />
<?php if(!$hidePeople): ?>
<?php echo $__env->make('calculator.snippets.people', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?> 
  <input id="children" type="hidden" name="children" value="<?php echo empty($myTrip->children)?0:$myTrip->children;?>"/>
  <input id="adults" type="hidden" name="adults" value="<?php echo $myTrip->adults;?>"/>
<?php endif; ?>

<?php if(!empty($currentTour->waterSport)): ?>
<br>
<div class="" >
<label for="special-activity">People <?php echo $currentTour->waterSport == 'Ski'?'Waterskiing':'Flyboarding'; ?></label>
  <select name="special-activity" id="special-activity" required class="form-control">
    <option value="1" <?php echo $myTrip->specialActivity == 1? 'selected':'';?> >1</option>
    <option value="2" <?php echo $myTrip->specialActivity == 2? 'selected':'';?> >2</option>
    <option value="3" <?php echo $myTrip->specialActivity == 3? 'selected':'';?> >3</option>
    <option value="4" <?php echo $myTrip->specialActivity == 4? 'selected':'';?> >4</option>
    <option value="5" <?php echo $myTrip->specialActivity == 5? 'selected':'';?> >5</option>
  </select>
</div>
<?php endif; ?>
<?php echo $__env->make('calculator.snippets.additional-considerations', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
