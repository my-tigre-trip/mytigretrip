<div class="" >
<label for="adults">Adults </label>
  <select name="adults" id="adults" class="form-control">
    <option > </option>
    <option value="2" <?php echo $myTrip->adults == 2? 'selected':'';?> >2</option>
    <option value="3" <?php echo $myTrip->adults == 3? 'selected':'';?> >3</option>
    <option value="4" <?php echo $myTrip->adults == 4? 'selected':'';?> >4</option>
    <option value="5" <?php echo $myTrip->adults == 5? 'selected':'';?> >5</option>
  </select>
</div>
<br>
<?php //if (!$isLuxury) : ?>
<div class="" >
<?php if (!$isLuxury) : ?>
<label for="children"><div class="tooltip">Children<span class="tooltiptext">Paying children are more than 2 and under 10 years of age.</span></div></label>
<?php else:  ?>
  <label for="children"><div class="tooltip">Children<span class="tooltiptext">This Mood is not suggested for children</span></div></label>
<?php endif;  ?>
  <select name="children" id="children" <?php echo $isLuxury? 'disabled':'' ;?> class="form-control" >
    <option value="0" <?php echo ($myTrip->children == '0' || $isLuxury )? 'selected':'';?> >0</option>
    <option value="1" <?php echo $myTrip->children == '1'? 'selected':'';?> >1</option>
    <option value="2" <?php echo $myTrip->children == '2'? 'selected':'';?> >2</option>
    <option value="3" <?php echo $myTrip->children == '3'? 'selected':'';?> >3</option>
  </select>

</div>
