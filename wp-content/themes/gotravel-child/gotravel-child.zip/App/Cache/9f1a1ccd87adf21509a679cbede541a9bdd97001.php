<?php 
$isLuxury = null;
$isRanch = null;
if ($myBoat->boat !== 'speedboat') {
	  $mainTour = $myBoat->mood1;
  	$isLuxury = $mainTour->isLuxury();
  	$isRanch = $mainTour->isRanch();
		
}
 ?>



		<select id="mtt-include-car" style='display:none;' name="car">

			<option value='Included' <?php echo ($myTrip->car || $myBoat->boat === 'full-day' )?'selected':''; ?> >Included</option>
			<option value='Not&#x20;Included' <?php echo !$myTrip->car && $myBoat->boat !== 'full-day' ?'selected':''; ?> >Not Included</option>
			<option value='Included&#x20;in&#x20;&#x20;Price'>Included in  Price</option>
		</select>

    <input type="hidden" name="language" value="en">
    <input id="mtt-ticket-number" type='hidden'   maxlength='255' name="ticketNumber" value="<?php echo $myTrip->id ?>"/>
		<input id="mtt-adults" type='hidden'  name="adults" value="<?php echo $myBoat->adults ?>" />
		<input id="mtt-children" type='hidden'  name="children" value="<?php echo $myBoat->children ?>"/>
    <input id="mtt-water-spot" type='hidden'   maxlength='255' name="waterSport" value="<?php echo $myBoat->specialActivityPeople ?>" />
	  <input id="mtt-island-expenses" type='hidden'  name="islandExpenses" value="<?php echo $myTrip->payOnIsland?'Not Included in Price':'Included in Price' ?>" />


	    <input id="mtt-dayOfWeek" type="hidden"  name="weekDay"  />

		 <!-- google calendarMM/dd/yyyy -->
     <input id="mtt-google-calendar" type="hidden"  name="googleDate"  />

		 <input type='hidden'  name="tripDuration" value="<?php echo $myBoat->boatName($myBoat->boat); ?>" />
		 <input type='hidden'  name="tripBoat" value="<?php echo $myBoat->boat; ?>" />
		 <input id="mtt-mood-1" type="hidden" name="mood1" value="<?php echo $myBoat->mood1->name;  ?>" >


		 <?php if ($myBoat->boat === 'full-day') :		 ?>
			<input id="mtt-mood-2" type="hidden" name="mood2" value="<?php echo $myBoat->mood2->name;  ?>" >
		 <?php endif ?>

	   <?php if ($myTrip->payOnIsland) :
					$price = $tourDetail['price'];
					//$selfPaidText = "additionally,  you have asked to pay for your own expenses in the islands -estimated at USD $price
					//Bare in mind that you will be needing extra cash; credit cards are rarely accepted on the islands.";
			?>
		  <input id="mtt-estimated-island-expenses" type='hidden' maxlength='255' name="estimatedIslandExpenses" value="<?php echo $price?>" />

	  <?php endif ?>


		<select  name="additionalConsiderations" style="display:none">
			<option value='-None-'>-None-</option>
			<?php if($isRanch || $isLuxury ): ?>
			<option value='Lunch&#x20;&#x2b;&#x20;1&#x20;Activity' <?php echo ($isRanch && $mainTour->optionalSelected)? 'selected' :'' ;?> >Lunch &#x2b; 1 Activity</option>
			<option value='Lunch&#x20;&#x2b;&#x20;2&#x20;Activities&#x20;&#x2b;&#x20;Tea' <?php echo ($isRanch && !$mainTour->optionalSelected)? 'selected' :'' ;?>>Lunch &#x2b; 2 Activities &#x2b; Tea</option>
			<option value='Use&#x20;of&#x20;Lodge&acute;s&#x20;Facilities&#x20;Included' <?php echo ($isLuxury && $mainTour->optionalSelected)? 'selected' :'' ;?>>Use of Lodge&acute;s Facilities Included</option>
			<option value='Use&#x20;of&#x20;Lodge&acute;s&#x20;Facilities&#x20;Not&#x20;Included' <?php echo ($isLuxury && !$mainTour->optionalSelected)? 'selected' :'' ;?>>Use of Lodge&acute;s Facilities Not Included</option>
		  <?php elseif($myBoat->boat !== 'speedboat' && ($myBoat->mood1->isWaterSport() || ($myBoat->mood2 !== null && $myBoat->mood2->isWaterSport())) ): ?>
			  <option value="<?php echo e($myBoat->mood1->specialActivityPeople); ?>" selected></option>
      <?php endif; ?>
		</select>



		<input id="mtt-final-price" type='hidden'   maxlength='255' name="amount" value="<?php echo e($finalPrice); ?>"/>
		<input id="mtt-final-price" type='hidden'   maxlength='255' name="groupDiscount" value="<?php echo e($boatDetail['groupDiscount']); ?>"/>
		<input id="mtt-final-price" type='hidden'   maxlength='255' name="priceBeforeDiscount" value="<?php echo e($finalPrice + $boatDetail['groupDiscount']); ?>"/>
