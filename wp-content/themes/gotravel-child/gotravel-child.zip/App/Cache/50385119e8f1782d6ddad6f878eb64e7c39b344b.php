<div class="col-sm-6 pb-3">
  <label for="first_name" class="d-none">First Name</label>
  <input type="text" class="form-control" id="first_name" placeholder="First Name *" name="firstName"  required>
  <input type="hidden" id="hidden_first_name"   name="firsName" >
</div>
<div class="col-sm-6 pb-3">
  <label for="first_name" class="d-none">Last Name</label>
  <input type="text" class="form-control" id="last_name" placeholder="Last Name *" name="lastName"  required>
  <input type="hidden" id="hidden_last_name"   name="LEADCF47" >
</div>

<div class="col-sm-6 pb-3">
  <label for="contactEmail" class="d-none">Email: </label>
  <input type="text" class="form-control" id="contactEmail" placeholder="Email *" name="email"     
    required>
</div>

<div class="col-sm-6 pb-3">
  <label for="phone" class="d-none">WhatsApp / SMS *: </label>
  <input type="text" class="form-control" id="phone" placeholder="WhatsApp / SMS *" name="phone" required>
</div>

<div class="col-md-6 pb-3">
  <label for="alternativeContact">Alternative Contact Information (optional)</label>
  <textarea class="form-control" id="alternativeContact" name="alternativeContact"></textarea>
  <small class="text-info">

  </small>
</div>
