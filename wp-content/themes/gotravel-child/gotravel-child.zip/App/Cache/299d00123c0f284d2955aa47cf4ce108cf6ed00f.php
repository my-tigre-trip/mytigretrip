<?php 
$message = $t->mtt('no-boat-selected');
 ?>
<p><?php echo e($message); ?></p>
<a class="mtt-button mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-solid mtt-button"
href="<?php echo home_url(); ?>#boat-selection">Designe My Tigre Trip</a>
