<div class="col-sm-12 pb-3">
<ul class="list-group mtt-cal-notes">
    <li class="list-group-item" id="mtt-cal-airbnb"><span>Airbnb</span>
    <a href="https://www.airbnb.es/experiences/132729?euid=8492c50a-ff6c-6b98-0926-0e7c3ece1aea"
       target="_blank" 
    > (more info)
    </a>
    </li>
    <li class="list-group-item" id="mtt-cal-not-available"><span id="">Private Tour</span> (not available)</li>
    <li class="list-group-item" id="mtt-cal-not-confirmed"><span id="">Private Tour</span> (not confirmed)</li>
</ul>
</div>