<?php 
use MyTigreTrip\Translation;
$t = new Translation('contact-form-en');
 ?>

<?php $__env->startPush('javascript'); ?>
<?php echo $__env->make('scripts.mtt', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('scripts.zoho-validation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8 offset-md-1">
  <span class="anchor" id="formComplex"></span>
  <hr class="my-5">


  <!-- form complex example -->
  <div class="container">


    <div class="row justify-content-center">

      <div class="col-md-9 col-sm-12 pt-1">

        <div class="collapse" id="collapseExample" id="mtt-summary"><?php echo $__env->make('calculator.summary', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
      </div>
    </div>
    <div class="my-2">
      <a data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">#Review Trip Details +</a>
    </div>

  </div>
  <hr class="my-5">
  <p>Please complete the following information</p>
  <form id="mtt-checkout-form" action="/mytigretrip/checkout.php" method='POST' onSubmit='javascript:document.charset="UTF-8"; return checkMandatory()' accept-charset="UTF-8">
  <input type="hidden" name="_token" value="<?php echo e(session_id()); ?>"  />
  <?php echo $__env->make('zoho-form.zoho-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.personal-data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <hr class="my-3">
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.date-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <hr class="my-3">
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.car-pickup-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <hr class="my-3">
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.more-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
 <hr class="my-3">
   <?php echo $__env->make('zoho-form.hidden-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="form-row my-4">
    <button id="mtt-book-my-trip" class="btn btn-dark btn-mtt-checkout  mx-auto" type="submit"  name="book">Book Now!!</button>
  </div>
</form>
</div>

<div class="col-md-4">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script type="text/javascript">
  $("#mtt-book-my-trip").click(function(e){
       e.preventDefault();
       checkoutMyTrip();
  });
  function checkoutMyTrip(){

    formElement = document.getElementById("mtt-checkout-form");

    var xhr = new XMLHttpRequest();
    var formData = new FormData( formElement );
    //  var alertText = "Please check your data (First name, email, dates, etc.. ) and try againg. If this problem continues write a message to agus@mytigretrip.com";
    //console.log(formData);
    xhr.open("POST", '/mytigretrip/checkout.php');
    xhr.send(formData);
    xhr.addEventListener("readystatechange", function(e) {
                    var xhr = e.target;
                    if (xhr.readyState == 4) {
    //  console.log('h');
                        if(xhr.status == 200) {
                           // borramos mensajes de validacion existentes
                            //jQuery('.mtt-validation').remove();
                            newResponse = JSON.parse( xhr.response);
                            newResponse = newResponse.message;
                            console.log(newResponse);
                            if (newResponse.status === "success") {
                                window.location.replace(newResponse.redirect);
                            } else {
                                alert(newResponse.message);
                            }

                        } else {
                          alert(alertText);
                          console.log(xhr.statusText);
                        }
                    }
    });

  }
  //validacion
loadEvents() //cargar calendario
function loadEvents(options) {
  var xhr = new XMLHttpRequest();   
  xhr.timeout = 15000;
  var alertMsg = 'Something went wrong... please check your internet connection or reload this page';
  xhr.ontimeout = function (e) {
      alert(alertMsg);
  };
  xhr.onerror = function(error) {
      alert(alertMsg);
  }; 
  xhr.open("POST", '/mytigretrip/calendar.php')
  xhr.send()
  xhr.addEventListener("readystatechange", function(e) {
    var xhr = e.target
    if (xhr.readyState == 4) {
    //  console.log('h');
      if(xhr.status == 200) {
        jQuery('.mtt-loading').hide();
        newResponse = JSON.parse( xhr.response)
        var events = newResponse.message.data
        const  today = new Date()
        let  tomorrow = new Date()
        tomorrow.setDate(today.getDate() + 1)
        
        $('meta[name="mtt-events"]').attr("content",JSON.stringify(events))
        // datepicker = $('[data-toggle="datepicker"]').datepicker(options);
        $( "#datepicker" ).datepicker({
          defaultDate: null,
          minDate: tomorrow,
          maxDate: "+1y +1m",
          beforeShowDay: function(date) {
            let cDate = dateToString(new Date(date))
            for(let i = 0; i < events.length; i++) {
              let eDate = dateToString(new Date(events[i].start))               
              if (eDate === cDate) {
              //  console.log( date+ ' -- '+eDate+' : ')
                //return [false, 'mtt-not-available']
                //if( events[i].time !== '') {
                 // return [true,"mtt-available "+events[i].status+" "+events[i].time] 
                if(date > today && (events[i].status == 'mtt-available' || events[i].status == 'not-confirmed')) {  
                  return [true,"mtt-available "+events[i].status+" "+events[i].time] 
                } else {
                  return [false, events[i].status]
                }                  
              } 
              //console.log('St evento  '+ events[i].start)   
            }
            return [true,"mtt-available"]              
          },
          onSelect: function(selected, dp) {           
            var date = new Date(selected)
            //console.log(date)
            $("select[name='day']").val(date.getDate())
            $("select[name='month']").val(date.getMonth()+1)
            $("select[name='year']").val(date.getFullYear()) 
          }
        });

      //   console.log(events)
      } else {        
        console.log(xhr.statusText)
      }
    }
  });
} 
//converts date to string
function dateToString(eDate) {
  var eMonth = eDate.getUTCMonth() + 1; //months from 1-12
  var eDay = eDate.getUTCDate();
  var eYear = eDate.getUTCFullYear();
  return  eDay+''+eMonth+''+eYear;
} 
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>