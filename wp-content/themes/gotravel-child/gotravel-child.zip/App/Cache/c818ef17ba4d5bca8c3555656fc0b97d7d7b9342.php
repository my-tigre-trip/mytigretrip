<?php 
$priceTitle = '';
if ($myTrip->payOnIsland) {
    $priceTitle = 'Subtotal';
} else {
    $priceTitle = 'Final Price';
}

 ?>

<?php if($myTrip->payOnIsland): ?>
<?php echo $__env->make('calculator.summary-pay-island', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<?php echo $__env->make('calculator.summary-pay-advance', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

  <div class=" p-0 my-3">
    <?php echo $__env->make('calculator.notes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
