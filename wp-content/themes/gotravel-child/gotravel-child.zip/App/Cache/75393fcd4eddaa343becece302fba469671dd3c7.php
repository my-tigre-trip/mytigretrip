<div class="py-2 w-100"></div>
  <!-- <label class="mtt-hide-with-pick"><small class="text-info">If you want to stay in Continental Tigre a little longer, just tell us so on the day of your trip.</small></label>
  <label class="mtt-show-with-pick text-info" for="mtt-pickme-extra">Knowing that there is a 40-minute drive from BA City to Tigre, please pick me up from my requested address at.</label>
-->
<label for="driveDistance">Driving distance - BA City to Tigre</label>
<input class="form-control" id="driveDistance" type="text" name="" value="50 min" disabled>
