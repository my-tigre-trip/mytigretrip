<?php 
$priceTitle = 'Subtotal';
 ?>
<div class="card">
  <div class="card-body">
    <table class="table table-hover">
      <tbody>
          <tr>
            <th scope="row" class="text-left border-top-0" >Trip duration</th>
            <td class="border-top-0"><?php echo e($myBoat->boatName($myBoat->boat)); ?></td>
          </tr>
          <?php if($myBoat->boat !== 'speedboat' ): ?>
          <tr>
            <th scope="row" >I'm in a mood for </th><td><?php echo e($myBoat->mood1->name); ?></td>
          </tr>
          <?php endif; ?>

          <?php if($myBoat->boat === 'full-day' && $myBoat->mood2->category->slug === 'build-your-own-tigre-trip-stop'): ?>
          <tr>
            <th scope="row" >I'm also in a mood for </th><td><?php echo e($myBoat->mood2->name); ?></td>
          </tr>
          <?php endif; ?>

      </tbody>
    </table>

    <table class="table table-hover table-light border rounded mt-4 table-striped">
      <tbody>
        <?php if($myTrip->car): ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($myTrip->priceCar); ?></td><td >Private Car </td>
        </tr>
        <?php endif; ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($price['priceAdults']); ?></td><td  ><?php echo e($boatDetail['adults']); ?> Adults
            <small class="font-italic px-2"> / Private Boat Trip / self-paid expenses</small>
          </td>
        </tr>
        <?php if($boatDetail['children'] > 0): ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($price['priceChildren']); ?></td><td><?php echo e($boatDetail['children']); ?> Children
             <small class="font-italic px-2"> / Private Boat Trip / self-paid expenses</small></td>
        </tr>
        <?php endif; ?>

        <?php if($tourDetail['specialActivityPeople'] > 0): ?>
        <?php 
          $countWater = $tourDetail['specialActivityPeople'] > 1? 'Classes':'Class';
         ?>
        <tr >
          <td scope="row" class="text-center"></td><td><?php echo e($tourDetail['specialActivityPeople']); ?> <?php echo e($tourDetail['specialActivity']); ?> <?php echo e($countWater); ?></td>
        </tr>
        <?php endif; ?>

        <?php if($boatDetail['groupDiscount'] > 0): ?>
        <tr class="font-italic">
          <td scope="row" class="text-center">- <?php echo e($boatDetail['groupDiscount']); ?></td><th scope="row" >Group Discount</th>
        </tr>
        <?php endif; ?>
        <tr class="font-bold mtt-color">
          <td scope="row" class="text-center"><b><?php echo e($finalPrice); ?></b></td><th scope="row" ><?php echo e($priceTitle); ?>

             <small class="font-italic px-2">/ no lunch or additional activities included</small> </th>
        </tr>

      </tbody>
    </table>
  </div>
</div>
