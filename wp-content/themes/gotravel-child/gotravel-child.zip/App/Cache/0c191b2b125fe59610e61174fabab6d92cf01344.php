<script type="text/javascript">
$(document).ready(function(){
//alert('dd');
  //console.log(jQuery('input[name="adults"]').val());
//  validatePassengers();
  checkTerms();
  //si tiene un opcional horario de pick
  pickOptions();

  if(jQuery('#mkdf-tour-booking-form').length > 0){
    if( jQuery('select[name="adults"]').val() !== '' ){
      sendCalculatorRequest();
    }
  }

  if(jQuery('#mtt-my-trip-form').length > 0){
    updateSummaryRequest();
  }
//formElement = document.getElementById("stories_search");
    jQuery('#calculate').on('click',function(e){
     e.preventDefault();
     sendCalculatorRequest();
     toogleCalculate();
    });
    //actualizar con opcionales en calculadora
    jQuery('.update-calculator').on('click',function(e){
      erasePriceDetails();
      sendCalculatorRequest();
    // toogleCalculate();
    });


//formcontacto
    jQuery('#terms').on('click',function(e){
      checkTerms();
    });

    jQuery('#mtt-get-my-trip-disabled').on('click',function(e){
      e.preventDefault();
      if( !checkTerms() ){
        alert("Please acept Terms & Conditions");
      }
    });

    jQuery('#mtt-get-my-trip').on('click',function(e){
     e.preventDefault();
     getMyTrip();
    });

//boton hacia my  trip
    jQuery('#next-step-button').on('click',function(e){
     //e.preventDefault();
    });

    jQuery('select').on('change',function(e){
        validatePassengers();
        jQuery('#next-step-button').hide();
    });

    jQuery('#mtt-my-trip-form input[type="checkbox"]').on('click',function(e){
      	//e.preventDefault();
        if($(this).hasClass('updateSummary')){
            updateSummaryRequest();
        }

    });

function sendCalculatorRequest(){
    //alert('dffgfgfdgfgdgfsdfd');
    formElement = document.getElementById("mkdf-tour-booking-form");
    erasePriceDetails();
    jQuery('.mtt-loading').show();
    var xhr = new XMLHttpRequest();
    var formData = new FormData( formElement );

    //console.log(formData);

    xhr.open("POST", '/mytigretrip/price-calculator.php');
    xhr.send(formData);

    xhr.addEventListener("readystatechange", function(e) {
                    var xhr = e.target;
                    if (xhr.readyState == 4) {
  //  console.log('h');
                        if(xhr.status == 200) {
                          jQuery('.mtt-loading').hide();
                          //  console.log('200');
                            newResponse = JSON.parse( xhr.response);
                            var messages= newResponse.messages ;
                            var view = newResponse.view;
                            var nextStep = newResponse.nextStep;
                            var valid = newResponse.valid;

                            jQuery('#mtt-messages').empty();
                          //  jQuery('#mtt-messages').append(valid.messages);
                            toogleCalculate();
                            if(valid.valid){
                              console.log('el precio es valido');
                              //erasePriceDetails();
                              erasePriceDetails();
                              jQuery('#mtt-price-detail').append(view);
                              jQuery('#next-step').attr('href',nextStep);
                              jQuery('#mkdf-tour-booking-form').attr('action',nextStep);
                              jQuery('#next-step-button').show();
                              jQuery('#calculate').hide();
                            }else {
                              console.log('el precio NO es valido');
                              jQuery('#next-step-button').hide();
                              jQuery('#calculate').hide();

                            }
                        } else console.log(xhr.statusText);
                    }
    });

}


function updateSummaryRequest(){

    formElement = document.getElementById("mtt-my-trip-form");
    jQuery('#mtt-summary').empty();
    jQuery('.mtt-loading').show();

    var xhr = new XMLHttpRequest();
    var formData = new FormData( formElement );

    var object = {};
    formData.forEach(function(value, key){
      object[key] = value;
    });
    var json = JSON.stringify(object);
    //console.log(json);
    carContent();

    //scroll arriba
    $('html, body').animate({
          scrollTop:  0
        }, 500);

    xhr.open("POST", '/mytigretrip/summary.php');
    xhr.send(formData);

    xhr.addEventListener("readystatechange", function(e) {
                    var xhr = e.target;
                    if (xhr.readyState == 4) {
  //  console.log('h');
                        if(xhr.status == 200) {

                            newResponse = JSON.parse( xhr.response);
                            var payOnIsland= newResponse.payOnIsland ;
                            var view = newResponse.view;


                            jQuery('#mtt-summary').append(view);
                            jQuery('.mtt-loading').hide();

                            if(payOnIsland){
                              jQuery('.mtt-tour-detail .mtt-price').css('text-decoration','line-through');
                            }else{
                              jQuery('.mtt-tour-detail .mtt-price').css('text-decoration','none');
                            }

                        } else {
                          jQuery('#mtt-summary').append('<p class="mtt-alert">An error ocurred. Please check your connection and try again</p>');
                          jQuery('.mtt-loading').hide();
                          console.log(xhr.statusText);
                        }
                    }
    });

}
//-------------------
function getMyTrip(){
  formElement = document.getElementById("mtt-my-trip-form");

  var xhr = new XMLHttpRequest();
  var formData = new FormData( formElement );
  //console.log(formData);
  xhr.open("POST", '/mytigretrip/get-the-trip.php');
  xhr.send(formData);
  xhr.addEventListener("readystatechange", function(e) {
                  var xhr = e.target;
                  if (xhr.readyState == 4) {
  //  console.log('h');
                      if(xhr.status == 200) {
                         // borramos mensajes de validacion existentes
                          jQuery('.mtt-validation').remove();
                          newResponse = JSON.parse( xhr.response);
                          if (newResponse.errors == false) {

                              window.location.replace(newResponse.redirect);
                              console.log(newResponse.redirect);
                          } else {
                             var errors = newResponse.errors;
                             console.log(errors);
                             if( errors !== true ){
                                  for (var i=0; i < errors.length; i++ ) {
                                      console.log('error '+errors[i]);
                                      jQuery('#'+errors[i]).after('<p class="mtt-alert mtt-validation">Please check this required field</p>');
                                  }
                                  jQuery('html, body').animate({
                                        scrollTop: jQuery('#'+errors[0]).offset().top - 200
                                      }, 500);
                              }
                          }

                      } else console.log(xhr.statusText);
                  }
  });

}

});
///------

function passengersLimit(){
  var limit = 5;
  var count = parseInt(jQuery('select[name="adults"]').val()) + parseInt(jQuery('select[name="children"]').val());
  return count >limit ?true :false ;
}

function waterSportLimit(){
  if( jQuery('select[name="special-activity"]').length > 0 ){
    var limit = parseInt(jQuery('#adults').val()) + parseInt(jQuery('#children').val());
    var count = parseInt(jQuery('select[name="special-activity"]').val()) ;
    return count >limit ? true :false ;
  }
  return false;

}

function validatePassengers(){
  var error = 0;
  var message = "";
  erasePassengersLimitMessage();

  if( !areThereAdults()){
  //	message = "<p><br>How many guest will join in?</p>";

    error++;
  }else	if(passengersLimit()){
    message = "<p>Private speedboat trips have been designed for a minimum of 2 passengers and a maximum of 5 passengers per trip. However, if you place a request before checkout we will admit up to 6 passengers on a single trip. If you are part of a group of 6 to 25 people, please check our Cruise or Yacht Trips</p>";
    error++;
  }else if( waterSportLimit() ){
    message = "<p>Please check the 'Ski' or 'Flyboard' value</p>";
    error++;
  }

  if (error > 0) {
    jQuery('#mtt-large-group-message').append(message);
    jQuery('#calculate').hide();
    erasePriceDetails();
  } else {
    jQuery('#calculate').show();
  }

}

/**/
function toogleCalculate(){
  if( isEmpty(jQuery("#mtt-price-detail"))  &&
      isEmpty(jQuery("#mtt-large-group-message")) &&
      isEmpty(jQuery("#mtt-messages") )
    ){
        jQuery('#calculate').show();
  }else {
      jQuery('#calculate').hide();
  }
}



//////
function isEmpty( el ){
    return !jQuery.trim(el.html())
}

function erasePriceDetails()
{
    jQuery('#mtt-price-detail').empty();
}

function erasePassengersLimitMessage()
{
    jQuery('#mtt-large-group-message').empty();
}

function areThereAdults()
{
    var i = false;
    if(jQuery('select[name="adults"]').val() !== ''){
        i = true;
    }
    return i;
}


  //jQuery('.mtt-price-total-boat').hide();
  //console.log(jQuery('.mtt-price-total-boat'));

 jQuery('#timeOptions').change(function(e){
    pickOptions();
 });

 function pickOptions()
 {
   var pickme = jQuery('#timeOptions').find('.mtt-pickme');
   var selected = false;
   jQuery.each(pickme, function(key, value){
    //console.log('pick '+value.selected);
    if (value.selected) {
      selected = true;
      //console.log('pick '+selected);
    }
    });

    if (selected) {
      jQuery(".mtt-show-with-pick").show();
      jQuery(".mtt-hide-with-pick").hide();
    } else{
      jQuery(".mtt-show-with-pick").hide();
      jQuery(".mtt-hide-with-pick").show();
    }
    console.log('pick '+selected);
 }


function carContent()
{
  if (jQuery('input[name="car"]:checked').length > 0){
    jQuery(".mtt-show-with-car").show();
    jQuery(".mtt-hide-with-car").hide();
    //pickOptions();
  }else{
    jQuery(".mtt-show-with-car").hide();
    jQuery(".mtt-hide-with-car").show();
  }

}

function checkTerms()
{
  var checked = false;
  if (jQuery('input[name="terms"]:checked').length > 0){
    jQuery("#mtt-get-my-trip").show();
    jQuery("#mtt-get-my-trip-disabled").hide();
    checked = true;
    console.log('terms');
  }else{
    jQuery("#mtt-get-my-trip").hide();
    jQuery("#mtt-get-my-trip-disabled").show();
    console.log('NO terms');
  }
  return checked;
}

/*
//////
// Get the modal
var modal = document.getElementById('carModal');

// Get the button that opens the modal
var btn = document.getElementById("carModalTrigger");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function(e) {
  e.preventDefault();
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}*/

</script>
