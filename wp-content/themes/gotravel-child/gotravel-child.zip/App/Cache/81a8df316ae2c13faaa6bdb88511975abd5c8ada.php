<?php 
//$myTrip = unserialize($_SESSION['myTrip']);

$priceTitle = '';
if ($myTrip->boat == 'full-day' && $myTrip->fullStop === null && $myTrip->preBuilt === null) {
    $priceTitle = 'Subtotal';
} else {
    $priceTitle = 'Final Price';
}

//tourSlug

$mainTour = $myTrip->mainTour();

//parada adicional
$additionalTour = $myTrip->additionalTour();
if ($additionalTour != '') {

}

 ?>

<?php if($myTrip->payOnIsland): ?>
<?php echo $__env->make('calculator.summary-pay-island', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<?php echo $__env->make('calculator.summary-pay-advance', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
  <div class=" p-0 my-3">
    <?php echo $__env->make('calculator.unit-prices', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class=" p-0 my-3">
    <?php echo $__env->make('calculator.notes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
