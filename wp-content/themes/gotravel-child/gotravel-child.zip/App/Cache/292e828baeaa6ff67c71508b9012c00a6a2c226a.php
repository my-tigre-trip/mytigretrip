<?php if($myBoat->mood1->schedule === 'morning'): ?>
  <?php echo $__env->make('zoho-form.snippets.morning-schedule', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
  <?php echo $__env->make('zoho-form.snippets.not-morning-schedule', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<div class="mt-2 w-100"></div>
<label for="mtt-pickup-address" >Pick Up Adress - from BA City*:</label></br>
<textarea class="form-control" id="mtt-pickup-address" name="pickupAddress" maxlength='2000' required></textarea>

<?php $__env->startPush('javascript'); ?>
<script type="text/javascript">
var carPickupTime = {
  "10 am":["9.10 am"],
  "10.30 am":["9.40 am"],
  "11 am":["10.10 am"],
  "3 pm": ["10 am", "10.30 am", "11 am", "11.30 am",
      "12 pm", "12.30 pm", "13 pm", "13.30 pm", "14.10 pm"],
  "3.30 pm": ["10 am", "10.30 am", "11 am", "11.30 am",
      "12 pm", "12.30 pm", "13 pm", "13.30 pm","14 pm", "14.30 pm", "14.40 pm"]
}

var departureTimeMorning = {
  "9.10 am":["10 am"],
  "9.40 am":["10.30 am"],
  "10.10 am":["11 am"]
}


function setCarPickUpTime()
{
  let time = $('select[name="departureTime"]').val();
  //limpiamos carPickupTime
  $('select[name="carPickupTime"] option').remove();

  //  console.log('departureTime selected '+time);
  let options = carPickupTime[time];
  //console.log('Nr pick up options '+options.length);
  for(var i = 0; i < options.length; i++){
    let selected = (i+1) == options.length? 'selected': '';
    let addOption = '<option value="'+options[i]+'" '+selected+' >'+options[i]+'</option>';
    console.log('pick up option: '+options[i]);
    $('select[name="carPickupTime"]').append(addOption);
  }
}

function setBoatDepartureTime()
{
  let time = $('select[name="carPickupTime"]').val();
  //limpiamos carPickupTime
  $('select[name="departureTime"] option').remove();

  //  console.log('departureTime selected '+time);
  let options = departureTimeMorning[time];
  //console.log('Nr pick up options '+options.length);
  for(var i = 0; i < options.length; i++){
    let selected = (i+1) == options.length? 'selected': '';
    let addOption = '<option value="'+options[i]+'" '+selected+' >'+options[i]+'</option>';
    console.log('pick up option: '+options[i]);
    $('select[name="departureTime"]').append(addOption);
  }
}

$(document).ready(function(){
  if ($('meta[name="schedule"]').attr("value") === 'morning')
  {
    console.log("mor");
    setBoatDepartureTime()  
    $('select[name="carPickupTime"]').change(function(){
      setBoatDepartureTime()
    });
  } else {
    setCarPickUpTime();
    $('select[name="departureTime"]').change(function(){
      setCarPickUpTime()
    });
  }
   
});
</script>
<?php $__env->stopPush(); ?>
