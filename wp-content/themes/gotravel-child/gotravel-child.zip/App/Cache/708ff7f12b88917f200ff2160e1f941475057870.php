<div class="col-md-6  pb-3 form-group clear">
  <label for="menu-requirements">Special Menu Requests <small class="text-info">-please tell us more under the "Notes & Comments” section</small></label>
  <select id="menu-requirements" name="specialMenuRequirements" class="form-control">
    <option value='-None-'>-None-</option>
    <option value='Gluten&#x20;Free&#x20;Meal'>Gluten Free Meal</option>
    <option value='Vegetarian&#x20;Meal'>Vegetarian Meal</option>
  </select>
</div>
<div class="w-100"></div>
<div class="col-md-6 pb-3 form-group clear">

    <label for="alternativeContactInformation">Notes & Comments (optional)</label>
    <textarea class="form-control" id="alternativeContactInformation" name="notesComents"></textarea>
    <small class="text-info">

    </small>
</div>
