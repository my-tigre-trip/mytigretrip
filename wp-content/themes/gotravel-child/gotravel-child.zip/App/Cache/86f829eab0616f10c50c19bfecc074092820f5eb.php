<?php 
use MyTigreTrip\Translation;
$t = new Translation('contact-form-en');
 ?>

<?php $__env->startPush('javascript'); ?>
<?php echo $__env->make('scripts.mtt', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('scripts.zoho-validation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-7 offset-md-1">
  <span class="anchor" id="formComplex"></span>
  <hr class="my-5">


  <!-- form complex example -->
  <div class="container">
    <div class="row ">
      <div class="col-md-9 col-sm-12 p-0">
        <div id="mtt-summary"><?php echo $__env->make('calculator.summary', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
      </div>
    </div>

  </div>
  <hr class="my-5">
  <form id="mtt-checkout-form" action="/mytigretrip/checkout.php" method='POST' onSubmit='javascript:document.charset="UTF-8"; return checkMandatory()' accept-charset="UTF-8">
  <input type="hidden" name="_token" value="<?php echo e(session_id()); ?>"  />
  <?php echo $__env->make('zoho-form.zoho-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.personal-data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.date-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <hr class="my-3">
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.car-pickup-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <hr class="my-3">
  <div class="form-row mt-4">
    <?php echo $__env->make('zoho-form.more-info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
 <hr class="my-3">
   <?php echo $__env->make('zoho-form.hidden-fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="form-row my-4">
    <button id="mtt-book-my-trip" class="btn btn-dark" type="submit"  name="book">Book My Tigre Trip Now</button>
  </div>
</form>
</div>

<div class="col-md-4">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script type="text/javascript">
  $("#mtt-book-my-trip").click(function(e){
       e.preventDefault();
       checkoutMyTrip();

  });
  function checkoutMyTrip(){

    formElement = document.getElementById("mtt-checkout-form");

    var xhr = new XMLHttpRequest();
    var formData = new FormData( formElement );
    var alertText = "Please check your data (First name, email, dates, etc.. ) and try againg. If this problem continues write a message to agus@mytigretrip.com";
    //console.log(formData);
    xhr.open("POST", '/mytigretrip/checkout.php');
    xhr.send(formData);
    xhr.addEventListener("readystatechange", function(e) {
                    var xhr = e.target;
                    if (xhr.readyState == 4) {
    //  console.log('h');
                        if(xhr.status == 200) {
                           // borramos mensajes de validacion existentes
                            //jQuery('.mtt-validation').remove();
                            newResponse = JSON.parse( xhr.response);
                            //console.log(newResponse);
                            if (newResponse.status === "success") {
                                window.location.replace(newResponse.redirect);
                            } else {
                                alert(alertText);
                            }

                        } else {
                          alert(alertText);
                          console.log(xhr.statusText);
                        }
                    }
    });

  }


  //validacion

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>