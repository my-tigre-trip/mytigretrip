<?php
use MyTigreTrip\Translation;

session_start();

    $t = new Translation('calculator-en');
    global $wp;
    $currentTour = getCurrentTour();
print_r($currentTour);
    $myTrip = unserialize($_SESSION['myTrip']);
    $current_url = home_url(add_query_arg(array(), $wp->request));
    $action = '';

    $valid = validateCalculator($myTrip);

    if ($myTrip->boat !== null ) {
        if ( $myTrip->stage === 'calculator' ) {
            $myTrip->clearStoredTour(get_the_ID());
        }

        $_SESSION['myTrip'] =  serialize($myTrip);
        $showAlert = false;
        $adults = $myTrip->adults;
        $children =  $myTrip->children;

        $action = $myTrip->goto;

        $nextButton = 'This is my Trip!';
        if (isTourCategory('build-your-own-trip-lunch', get_the_ID())) {
            $nextButton = 'Select & Continue!';
        }

        $hidePeople = false;
        if (isTourCategory('build-your-own-tigre-trip-stop', get_the_ID())) {
            $hidePeople = true;
        }

        $goBack = getGoBackUrl($myTrip);

    } else {
        $showAlert = true;
    }
    $isLuxury = $currentTour->optional == 'luxury'?true:false;
    $isRanch = $currentTour->optional == 'ranch'?true:false;

	?>
	<div class="mkdf-tour-booking-form-holder mkdf-boxed-widget">

	<h5 class="mkdf-tour-booking-title">Plan your Tigre Trip with us today!</h5>
  <div id="mtt-validator-messages">
  <?php if($valid !== true): ?>
     <?php echo $__env->make('calculator.messages.'.$valid, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php elseif($valid === true): ?>
  </div>

	<form id="mkdf-tour-booking-form" method="post" action="" class="mtt-form">
    <?php echo $__env->make('calculator.snippets.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="mtt-loading mtt-loading-calculator">
        <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
        <span class="sr-only">Loading...</span>
    </div>
		<div id="booking-validation-messages-holder"></div>
		<div id="mtt-price" >
			<div id="mtt-price-detail"></div>
			<div id="mtt-messages"></div>
      <div id="mtt-large-group-message"></div>
		</div>

		<div class="mtt-calculator-buttons">

      <button id="calculate" type="submit" class="mtt-button mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-solid mtt-get-price mtt-button">Calculate</button>
      <a aria-hidden="select this option" id="next-step" class="mtt-select-option" href="##"><button id="next-step-button"  type="submit" class="mtt-button mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-solid mtt-get-price mtt-button"><?php echo $nextButton; ?></button>
      </a>
    </div>
    <div class="mtt-goback vc_col-12">
       <a aria-hidden="go back" class="left" href="<?php echo e($goBack); ?>"><i class="fa fa-arrow-circle-o-left"></i></a>
    </div>
		<div>
      <?php if( false ):  ?>
			<a  href="<?php echo home_url() ?>/clear-option/"><i class="fa fa-times-circle" aria-hidden="true"></i></a>
			<?php endif; ?>
		</div>
   <?php endif; ?>
	</form>
</div>
