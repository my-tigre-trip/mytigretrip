<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Tigre Trip</title>
    <?php 
    $templateFolder = get_template_directory_uri();
     ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!--  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet"> -->
     <link href="https://fonts.gstatic.com/s/raleway/v12/1Ptug8zYS_SKggPNyC0ITw.woff2" type="font/woff2" rel="stylesheet"> 
    <link rel="stylesheet" id="mkdf_font_elegant-css" href="<?php echo e($templateFolder); ?>/assets/css/elegant-icons/style.min.css?ver=4.8.6" type="text/css" media="all">
    <link rel="stylesheet" id="mkdf_font_awesome-css" href="<?php echo e($templateFolder); ?>/assets/css/font-awesome/css/font-awesome.min.css?ver=4.8.6" type="text/css" media="all">
    <?php echo $__env->make('style.font', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
  <div class="container">
  <header class="py-2">
      <?php 
        $logo = wp_upload_dir();
      //  print_r($logo);
       ?>

       <div class="row">
       <div class="col-md-4 offset-md-3 col-sm-12">
          <div class="text-center">
             <img src="<?php echo e($logo['baseurl']); ?>/2016/04/logo-mtt3.png" class="img-fluid" alt="My tigre trip Logo">
          </div>
        </div>
       </div>
  </header>

  <?php echo $__env->yieldContent('content'); ?>

  </div>
  <?php echo $__env->make('snippets.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <script src="<?php echo e(get_template_directory_uri()); ?>/assets/js/jquery-3.3.1.min.js" type="text/javascript"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <?php echo $__env->yieldPushContent('javascript'); ?>
</body>
</html>
