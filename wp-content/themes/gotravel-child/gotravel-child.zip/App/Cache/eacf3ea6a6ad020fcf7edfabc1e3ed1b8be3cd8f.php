<?php 
$priceTitle = 'Subtotal';
 ?>
<div class="card">
  <div class="card-header">
    <span class="d-none d-md-inline">My Tigre Trip Details</span>
    <span class="float-md-right float-sm-left"><b><?php echo e($priceTitle); ?></b>
    <span class="badge badge-success p-2"><?php echo e($myTrip->currency); ?> <?php echo e($myTrip->price); ?></span></span>

  </div>

  <div class="card-body">
    <table class="table table-hover">
      <tbody>
          <tr>
            <th scope="row" class="text-left" >Duration</th>
            <td><?php echo e($myTrip->boatName()); ?></td>
          </tr>
          <?php if($mainTour != ''): ?>
          <tr>
            <th scope="row" >I'm in a mood for </th><td><?php echo e($mainTour->name); ?></td>
          </tr>
          <?php endif; ?>

          <?php if($additionalTour != ''): ?>
          <tr>
            <th scope="row" >I'm also in a mood for </th><td><?php echo e($additionalTour->name); ?></td>
          </tr>
          <?php endif; ?>

      </tbody>
    </table>

    <table class="table table-hover table-light border rounded mt-4 table-striped">
      <tbody>
        <?php if($myTrip->car): ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($myTrip->carPrice); ?></td><td >Private Car </td>
        </tr>
        <?php endif; ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($myTrip->boatPriceAdults); ?></td><td  ><?php echo e($myTrip->adults); ?> Adults
            <small class="font-italic px-2"> / Private Boat Trip / self-paid expenses</small>
          </td>
        </tr>
        <?php if($myTrip->children > 0): ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($myTrip->boatPriceChildren); ?></td><td><?php echo e($myTrip->children); ?> Children
             <small class="font-italic px-2"> / Private Boat Trip / self-paid expenses</small></td>
        </tr>
        <?php endif; ?>

        <?php if($myTrip->specialActivity > 0): ?>
        <?php 
        $countWater = $myTrip->specialActivity > 1? 'Classes':'Class';
         ?>
        <tr >
          <td scope="row" class="text-center"><?php echo e($myTrip->waterSportPrice); ?></td><td><?php echo e($myTrip->specialActivity); ?> <?php echo e($myTrip->waterSport); ?> <?php echo e($countWater); ?></td>
        </tr>
        <?php endif; ?>

        <?php if($myTrip->groupDiscount > 0): ?>
        <tr class="font-italic">
          <td scope="row" class="text-center">- <?php echo e($myTrip->groupDiscount); ?></td><th scope="row" >Group Discount</th>
        </tr>
        <?php endif; ?>
        <tr class="font-bold table-primary">
          <td scope="row" class="text-center"><b><?php echo e($myTrip->price); ?></b></td><th scope="row" ><?php echo e($priceTitle); ?>

             <small class="font-italic px-2">/ no lunch or additional activities included</small> </th>
        </tr>


      </tbody>
    </table>
  </div>
</div>
