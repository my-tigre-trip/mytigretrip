<?php 
//$carStatus =
 ?>



		<select id="mtt-include-car" style='display:none;' name="car">

			<option value='Included' <?php echo ($myTrip->car || $myTrip->boat === 'full-day' )?'selected':''; ?> >Included</option>
			<option value='Not&#x20;Included' <?php echo !$myTrip->car && $myTrip->boat !== 'full-day' ?'selected':''; ?> >Not Included</option>
			<option value='Included&#x20;in&#x20;&#x20;Price'>Included in  Price</option>
		</select>


    <input id="mtt-ticket-number" type='hidden'   maxlength='255' name="ticketNumber" value="<?php echo $myTrip->id ?>"/>
		<input id="mtt-adults" type='hidden'  name="adults" value="<?php echo $myTrip->adults ?>" />
		<input id="mtt-children" type='hidden'  name="children" value="<?php echo $myTrip->children ?>"/>
    <input id="mtt-water-spot" type='hidden'   maxlength='255' name="waterSport" value="<?php echo $myTrip->specialActivity ?>" />
	  <input id="mtt-island-expenses" type='hidden'  name="islandExpenses" value="<?php echo $myTrip->payOnIsland?'Not Included in Price':'Included in price' ?>" />


	    <input id="mtt-dayOfWeek" type="hidden"  name="weekDay"  />

		 <!-- google calendarMM/dd/yyyy -->
     <input id="mtt-google-calendar" type="hidden"  name="googleDate"  />
		 <input type='hidden'  name="tripDuration" value="<?php echo $myTrip->boatName() ?>" />
		 <input id="mtt-mood-1" type="hidden" name="mood1" value="<?php echo $myTrip->mainTour()->name;  ?>" >

		 <?php if ($myTrip->boat == 'full-day'  && $myTrip->preBuilt === null) :		 ?>
			<input id="mtt-mood-2" type="hidden" name="mood2" value="<?php echo $myTrip->additionalTour()->name;  ?>" >
		 <?php endif ?>

	   <?php if ($myTrip->payOnIsland) :
					$price = $myTrip->tourPrice + $myTrip->waterSportPrice ;
					$selfPaidText = "additionally,  you have asked to pay for your own expenses in the islands -estimated at USD $price
					Bare in mind that you will be needing extra cash; credit cards are rarely accepted on the islands.";
			?>
		  <input id="mtt-estimated-island-expenses" type='hidden' maxlength='255' name="estimatedIslandExpenses" value="<?php echo $price?>" />
			<input type="hidden" name="payOnIslandText" value="<?php echo $selfPaidText;  ?>" />
	  <?php endif ?>

		<?php if($myTrip->boat == 'full-day'  && $myTrip->preBuilt !== null):
			$mainTour = $myTrip->mainTour();
			$isLuxury = $mainTour->optional == 'luxury'?true:false;
      $isRanch = $mainTour->optional == 'ranch'?true:false;
			?>
		<select  name="additionalConsiderations" style="display:none">
			<option value='-None-'>-None-</option>
			<option value='Lunch&#x20;&#x2b;&#x20;1&#x20;Activity' <?php echo ($isRanch && $myTrip->ranch)? 'selected' :'' ;?> >Lunch &#x2b; 1 Activity</option>
			<option value='Lunch&#x20;&#x2b;&#x20;2&#x20;Activities&#x20;&#x2b;&#x20;Tea' <?php echo ($isRanch && !$myTrip->ranch)? 'selected' :'' ;?>>Lunch &#x2b; 2 Activities &#x2b; Tea</option>
			<option value='Use&#x20;of&#x20;Lodge&acute;s&#x20;Facilities&#x20;Included' <?php echo ($isLuxury && $myTrip->luxury)? 'selected' :'' ;?>>Use of Lodge&acute;s Facilities Included</option>
			<option value='Use&#x20;of&#x20;Lodge&acute;s&#x20;Facilities&#x20;Not&#x20;Included' <?php echo ($isLuxury && !$myTrip->luxury)? 'selected' :'' ;?>>Use of Lodge&acute;s Facilities Not Included</option>

		</select>
	<?php endif; ?>


		<input id="mtt-final-price" type='hidden'   maxlength='255' name="amount" value="<?php echo $myTrip->price?>"/>
		<input  type="hidden" name='LEADCF66' value="<?php echo $myTrip->price?>" />
