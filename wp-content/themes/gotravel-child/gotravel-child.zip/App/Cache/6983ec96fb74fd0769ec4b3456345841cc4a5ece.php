<style media="screen">
html {
  font-size: 0.95rem;

}
body {
  font-family: 'Raleway', sans-serif;
}

<?php echo e('@'); ?>include media-breakpoint-up(sm) {
  html {
    font-size: 1.1rem;
  }
}

<?php echo e('@'); ?>include media-breakpoint-up(md) {
  html {
    font-size: 1.4rem;
  }
}

<?php echo e('@'); ?>include media-breakpoint-up(lg) {
  html {
    font-size: 1.5rem;
  }
}
footer {
  background-color: #282828;
  color:#808285;
}

</style>
