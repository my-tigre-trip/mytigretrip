<!-- Horarios de lancha o pick up -->
<div class="col-md-6 form-group pb-3">
 <?php  if ($myTrip->boat === 'full-day') : ?>
 <label for="mtt-pick-time" class="d-none"><?php $t->mtt('pick-up-time')?>. <?php $t->mtt('pick-up-time-info');?>:</label>
 <small class="text-info"><?php $t->mtt('pick-up-time')?>. <?php $t->mtt('pick-up-time-info');?></small>
 <?php  elseif ($myTrip->car) : ?>
 <label for="mtt-pick-time" ><?php $t->mtt('departure-time')?>: </label>
 <?php  else : ?>
 <label for="mtt-pick-time" >I´d like to start my boat trip from Tigre´s Public Pier at: </label>
 <?php  endif; ?>

 <?php if($myTrip->boat == 'full-day'):
     //departureTime   boat Departure time - Speedboat_Departure_Time
     //carPickupTime   car pick up time - Car_Pickup_Time
 ?>

 <select class="form-control" name="carPickupTime">
   <option value="10 am">10 am</option>
   <option value="10.30 am">10.30 am</option>
   <option value="11 am">11 am</option>
 </select>
 </div>
 <?php else: //no es full day?>
</div>
<div class="w-100"></div>
<div class="col-md-6 form-group pb-3">
 <select id="timeOptions" class="form-control" name="<?php echo $myTrip->car? 'departureTime': 'carPickupTime' ?>">
   <?php  if ($myTrip->car) : ?><option value="10 am">10 am</option><?php endif; ?>
   <option value="10.30 am">10.30 am</option>
   <option value="11 am">11 am</option>
   <option class="mtt-pickme" value="3 pm">3 pm</option>
   <option class="mtt-pickme" value="3.30 pm">3.30 pm</option>
 </select>
 </div>
 <?php endif; ?>


<?php if($myTrip->boat !== 'full-day' && $myTrip->car):
  // si sale a la tarde diferenciamos el pickme
?>
<div class="w-100"></div>
<div class="col-md-6 pb-3 form-group">
  <label class="mtt-hide-with-pick"><small class="text-info">If you want to stay in Continental Tigre a little longer, just tell us so on the day of your trip.</small></label>
  <label class="mtt-show-with-pick text-info" for="mtt-pickme-extra">Knowing that there is a 40-minute drive from BA City to Tigre, please pick me up from my requested address at.</label>
  <select id="mtt-pickme-extra"  class="form-control mtt-show-with-pick" name="carPickupTime">
   <option value="10 am">10 am</option>
   <option value="10.30 am">10.30 am</option>
   <option value="11 am">11 am</option>
   <option value="11.30 am">11.30 am</option>
   <option value="12 pm">12 pm</option>
   <option value="12.30 pm">12.30 pm</option>
   <option value="1 pm">1 pm</option>
   <option value="1.30 pm">1.30 pm</option>
   <option value="2 pm">2 pm</option>
   <option value="2.30 pm">2.30 pm</option>
 </select>
 <br>
 <p class="mtt-show-with-pick"><small class="text-info"> Please remember, our boat trip will start at 3 pm from Tigre´s Public Pier. We will meet you there!</small></p>
</div>
<?php endif; ?>

<?php if( $myTrip->car || $myTrip->boat == 'full-day' ): ?>
  <div class="w-100"></div>
 <div class="col-md-6 pb-3" >
   <label for="mtt-pickup-address" >Car Pick-up Address *:</label></br>
   <textarea class="form-control" id="mtt-pickup-address" name="pickupAddress" maxlength='2000' required></textarea>
 </div>
<!--Car Pick-up Time <input type='text' style='width:250px;'  maxlength='255' name='carPickupTime' /> -->
<?php endif; ?>
