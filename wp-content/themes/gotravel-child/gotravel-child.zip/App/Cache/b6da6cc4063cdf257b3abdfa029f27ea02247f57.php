<?php 
//$notes = 
 ?>
<?php if(count($notes) > 0): ?>
<div class="card">
  <div class="card-header">Notes
    <span class="float-right badge badge-danger p-2"><?php echo e(count($notes)); ?></span>
  </div>

  <div class="card-body">
    <ul class="list-group list-style px-3">
    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <li class="p-2"><?php echo $note; ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </ul>
  </div>
</div>
<?php endif; ?>
