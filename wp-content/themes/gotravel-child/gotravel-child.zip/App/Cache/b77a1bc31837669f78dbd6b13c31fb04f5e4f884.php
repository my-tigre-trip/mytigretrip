<footer class="py-5">

    <div class="text-center">
       My Tigre Trip -private boat tours. © Copyright 2014. All Rights Reserved.
    </div>

</footer>
