<?php

namespace App\Models;
use App\Models\Woo;

class Tour
{

    public $product;
    public $category;
    public $boat;
    public $mood; // 1 or 2

    public $id;
    public $slug;
    public $specialActivityPeople; //activity
    public $children;
    public $adults;
    public $price;
    public $name;
  //----------
    public $waterSport;
    public $optional = null;
    public $optionalSelected;
    public $schedule;
    public $notCompatible;


    public function __construct($sku)
    {
        if ($sku !== null) {
            $this->product = $this->find($sku);
            $this->category = Woo::getCategory($this->product);
            $this->boat = Woo::getTourBoat($this->category);
            $this->mood = Woo::getMood($this->category);

            $this->id = $product->id;
            $this->slug = $sku;
            //$this->people = $people;
            $this->price = $this->product->price ;
            $this->name = $this->product->name;
            $this->optionalSelected = false; // luxury & ranch
            $this->waterSport = $this->product->get_attribute('waterSport');
            $this->optional =  $this->product->get_attribute('optional');
            $this->notCompatible =  $this->product->get_attribute('notCompatible');
            if ($this->optional !== null) {
                $this->optional = $this->find($this->optional);
              //  $this->optional
            }
            $this->schedule =  $this->product->get_attribute('schedule');
            
        }
      /*
        $this->people = 0;
        $this->children = 0;
        $this->adults = 0;*/
    }

    public function find($sku)
    {
        return Woo::findProduct($sku);
    }

    /**
    *
    * @return string
    */
    public function getTourBoat()
    {
        return Woo::getCategory($this->product);
        /*
        $cat = $this->product->get_category_ids()[0];
        if( $term = get_term_by( 'id', $cat, 'product_cat' ) ){
            echo $term->name;
        }
*/
    /*  foreach($categories as $c){

        if(   in_array( $c->slug , $this->tourBoatCategories )  ){
            $category = $c->slug;

            break;
        }
      }*/
    }
    /**
    *
    *
    */
    public function getPrice()
    {
        $price = $this->product->price;
        $priceAdults = 0;
        $priceChildren = 0;
        $priceActivity = 0;

        if ($this->isWaterSport()) {
            $priceActivity = $price * $this->specialActivityPeople ;
        } elseif ($this->isRanch() || $this->isLuxury()) {
            if ($this->isRanch()) {
                $priceOptional = !$this->optionalSelected ? $this->optional->price : 0;
            } else {
                $priceOptional = $this->optionalSelected ? $this->optional->price : 0;
            }
            # chequear si esta seleccionada la opcion
            $priceAdults = ($price + $priceOptional) * $this->adults;
            $priceChildren = ($price + $priceOptional) * $this->children;
        } else {
            $priceAdults = $price * $this->adults;
            $priceChildren = $price * $this->children;
        }
        return [
            'priceAdults' => $priceAdults,
            'priceChildren' => $priceChildren,
            'priceActivity' => $priceActivity,
            'price' => $priceAdults + $priceChildren + $priceActivity
        ];
    }


    public function isLuxury()
    {
        return $this->optional !== null && !empty($this->optional) && $this->optional->get_sku() === 'luxury';
    }

    public function isRanch()
    {
        return $this->optional !== null && !empty($this->optional) && $this->optional->get_sku() === 'ranch';
    }

    /*ski*/
    public function isSki()
    {
        return $this->waterSport !== null && !empty($this->waterSport) && $this->waterSport === 'Ski';
    }

      /*flyboard*/
    public function isFlyboard()
    {
        return $this->waterSport !== null && !empty($this->waterSport) && $this->waterSport === 'Flyboard';
    }

    /*flyboard*/
    public function isWaterSport()
    {
        return ($this->isSki() || $this->isFlyboard() )?true:false;
    }

    public function isMorning()
    {
        return empty($this->schedule) || strpos($this->schedule, 'morning') !== false;
    }

    public function isAfternoon()
    {
       return ( empty($this->schedule)) || strpos($this->schedule, 'afternoon') !== false;
    }
}
