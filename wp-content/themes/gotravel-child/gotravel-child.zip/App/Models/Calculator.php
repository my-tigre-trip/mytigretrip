<?php
namespace App\Models;
//use Illuminate\Database\Eloquent\Model as Eloquent;
use App\Models\Woo;

class Calculator
{
    public function __construct()
    {

    }

    public static function boatName($boat)
    {
        return str_replace(['speedboat','half-day','full-day'], ['Speedboat Trip (no stops)','Half Day Trip','Full Day Trip'], $boat);
    }

    /**
    * @param $boat string
    * @param $adults integer
    * @param $children integer
    * @return array
    */

    public static function boatPrice($boat)
    {
       $people = $boat->adults + $boat->children;
       $basePrice = Woo::boatBasePrice($boat->boat);

       $priceAdultsDiscount = Woo::boatAdultsPrice($boat->boat, $boat->adults);
       $priceChildrenDiscount = Woo::boatChildrenPrice($boat->boat, $boat->children);
       $price = $priceAdultsDiscount+$priceChildrenDiscount;


       $priceBeforeDiscount = $basePrice * $people;

       $groupDiscount = $priceBeforeDiscount-$price;

       return [
           'status' => "valid",
           'boat' => $boat->boatName($boat->boat),
           'adults' => $boat->adults,
           'children' => $boat->children,
           'price' => $price,
           'priceChildren' => $basePrice*$boat->children,
           'discountChildren' => "60",
           'priceAdults' => $basePrice*$boat->adults,
           'discountAdults' => "40",
           'groupDiscount' => $groupDiscount ,
           'priceBeforeDiscount' => $priceBeforeDiscount
        ];
    }


    /**
    * tourPrice Calcula los precios de las paradas
    * @param array mood1 (y mood2)
    * @return array
    */
    public function tourPrice($mood1, $mood2 = null)
    {
        $price = 0;
        $price1 = $mood1->getPrice();
        $price = $price1['price'];
        $mood1PriceAdults = $price1['priceAdults'];
        $mood1PriceChildren = $price1['priceChildren'];
        $mood2PriceAdults = 0;
        $mood2PriceChildren = 0;

        //flyboard o ski
        $specialActivity = '';
        $specialActivityPrice = 0;
        $specialActivityPeople = 0;
        if ($mood1->isWaterSport()) {
            $specialActivity = $mood1->waterSport;
            $specialActivityPeople = $mood1->specialActivityPeople;
            $specialActivityPrice = $price1['priceActivity'];
        }

        //mood 2
        $mood2Name = '';
        if ($mood2 !== null) {
            $mood2Name = $mood2->name;
            $price2 = $mood2->getPrice();
            
            $price += $price2['price'];
            $mood2PriceAdults = $price2['priceAdults'];
            $mood2PriceChildren = $price2['priceChildren'];
            if ($mood2->isWaterSport()) {
                $specialActivity = $mood2->waterSport;
                $specialActivityPeople = $mood2->specialActivityPeople;
                $specialActivityPrice = $price2['priceActivity'];
            }
        }

        return [
          'status' => "valid",
          'mood1' => $mood1->name,
          'mood1PriceAdults' => $mood1PriceAdults,
          'mood1PriceChildren' => $mood1PriceChildren,

          'mood2' => $mood2Name,
          'mood2PriceAdults' => $mood2PriceAdults,
          'mood2PriceChildren' => $mood2PriceChildren,

          'specialActivity' => "$specialActivity",
          'specialActivityPrice' => $specialActivityPrice,
          'specialActivityPeople' => $specialActivityPeople,

          'additionalConsiderations' => "$additionalConsiderations",
          'price' => $price
        ];
    }

    /**
    *
    *
    */
    public function calculatePrice($boat, $myTrip = null)
    {
        $boatPrice = self::boatPrice($boat);
        if ($boat->boat === 'half-day') {
            $tourPrice = self::tourPrice($boat->mood1);
        } elseif ($boat->boat === 'full-day') {
            $tourPrice = self::tourPrice($boat->mood1, $boat->mood2);
        }

        $finalPrice = $boatPrice['price'];
        $priceAdults = $boatPrice['priceAdults'];
        $priceChildren = $boatPrice['priceChildren'];
        $priceSpecialActivity = 0;

        $payAdvance = $myTrip !== null? !$myTrip->payOnIsland: true;
        if ($payAdvance) {
            $finalPrice += $tourPrice['price'];
            $priceAdults += $tourPrice['mood1PriceAdults'] + $tourPrice['mood2PriceAdults'];
            $priceChildren += $tourPrice['mood1PriceChildren'] + $tourPrice['mood2PriceChildren'];
            //$priceSpecialActivity = $priceSpecialActivity;
        }

        //car
        $priceCar = 0;
        if ($myTrip !== null && $myTrip->car) {
            $priceCar = $myTrip->priceCar;
            $finalPrice += $priceCar;
        }

        return [
           'boatDetail' => $boatPrice,
           'tourDetail' => $tourPrice,
           'priceAdults' => $priceAdults,
           'priceChildren' => $priceChildren,
           'priceSpecialActivity' => $priceSpecialActivity,
           'car' => $priceCar,
           'finalPrice' => $finalPrice
        ];
    }
}
