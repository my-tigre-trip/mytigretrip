<script type="text/javascript">
jQuery(document).ready(function( $ ) {

	// $ Works! You can test it with next line if you like
	console.log($);

});
</script>
