<div class="mtt-loading mtt-loading-calculator">
        <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
        <span class="sr-only">Loading...</span>
    </div>
		<div id="booking-validation-messages-holder"></div>
		<div id="mtt-price" >
			<div id="mtt-price-detail"></div>
			<div id="mtt-messages"></div>
      <div id="mtt-large-group-message"></div>
</div>