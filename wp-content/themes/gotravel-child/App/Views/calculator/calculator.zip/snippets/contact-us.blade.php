<div class="mtt-calculator-buttons">

    <a href="mailto:agus@mytigretrip.com"  class="mtt-button mkdf-btn mkdf-btn-medium
     mkdf-btn-solid mkdf-btn-hover-solid mtt-get-price mtt-button">Contact Us</a>

</div>