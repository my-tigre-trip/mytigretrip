<p>Please before select this option pick first a Lunch option by clicking this following:</p>
<a class="mtt-button mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-solid mtt-button"
href="<?php echo home_url(); ?>/build-your-own-trip-lunch">Pick Lunch Option</a>
