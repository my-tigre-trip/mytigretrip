<?php 

if(mkdf_tours_visual_composer_installed()) {
	class WPBakeryShortCode_Mkdf_Tours_Slider_With_Filter extends WPBakeryShortCodesContainer {}
}